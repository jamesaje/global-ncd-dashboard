GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Noncommunicable diseases: Mortality
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/ncd-mortality
	Description: 
	Noncommunicable diseases (NCDs), such as heart disease, stroke, cancer, chronic respiratory diseases and diabetes, are the leading cause of mortality in the world. This invisible epidemic is an under-appreciated cause of poverty and hinders the economic development of many countries. The burden is growing - the number of people, families and communities afflicted is increasing. Common, modifiable risk factors underlie the major NCDs. They include tobacco, harmful use of alcohol, unhealthy diet, insufficient physical activity, overweight/obesity, raised blood pressure, raised blood sugar and raised cholesterol. The NCD threat can be overcome using existing knowledge. The solutions are highly cost-effective. Comprehensive and integrated action at country level, led by governments, is the means to achieve success.
	
	Date generated: 2025-04-28

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Noncommunicable diseases: Mortality"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: noncommunicable-diseases
	self: ncd-mortality
	children: 
		SDGSUICIDE	Crude suicide rates (per 100 000 population) (SDG 3.4.2)
		NCD_UNDER70	Premature deaths due to noncommunicable diseases (NCD) as a proportion of all NCD deaths
		NCDMORT3070	Probability of dying between the exact ages 30 and 70 years from cardiovascular diseases, cancer, diabetes, or chronic respiratory diseases (SDG 3.4.1)
		NCD_DTH_TOT	Total NCD Deaths
		WHS2_131	Total NCD mortality rate  (per 100 000 population) , age-standardized
	
